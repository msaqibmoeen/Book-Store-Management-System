import { useState } from 'react';
import axios from 'axios';

const CATEGORIES = ['Fiction', 'Non-Fiction', 'Science', 'Technology', 'History', 'Biography', 'Self-Help', 'Other'];

const initialForm = { title: '', author: '', price: '', category: '' };

export default function BookForm({ onBookAdded }) {
  const [form, setForm] = useState(initialForm);
  const [loading, setLoading] = useState(false);
  const [alert, setAlert] = useState(null);

  const showAlert = (type, message) => {
    setAlert({ type, message });
    setTimeout(() => setAlert(null), 4000);
  };

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.author || !form.price || !form.category) {
      showAlert('error', 'Please fill in all fields.');
      return;
    }
    if (isNaN(form.price) || Number(form.price) < 0) {
      showAlert('error', 'Please enter a valid price.');
      return;
    }

    setLoading(true);
    try {
      const res = await axios.post('/books', { ...form, price: Number(form.price) });
      if (res.data.success) {
        showAlert('success', '📚 Book added successfully!');
        setForm(initialForm);
        onBookAdded(res.data.data);
      }
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to add book. Is the server running?';
      showAlert('error', msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card">
      <div className="card-header">
        <div className="card-header-icon">📖</div>
        <div>
          <h2>Add New Book</h2>
          <p>Fill in the details below</p>
        </div>
      </div>
      <div className="card-body">
        {alert && (
          <div className={`alert alert-${alert.type}`} style={{ marginBottom: '1.25rem' }}>
            {alert.message}
          </div>
        )}
        <form className="form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label" htmlFor="title">Book Title</label>
            <input
              id="title"
              name="title"
              className="form-input"
              type="text"
              placeholder="e.g. The Great Gatsby"
              value={form.title}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="author">Author Name</label>
            <input
              id="author"
              name="author"
              className="form-input"
              type="text"
              placeholder="e.g. F. Scott Fitzgerald"
              value={form.author}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="price">Book Price ($)</label>
            <input
              id="price"
              name="price"
              className="form-input"
              type="number"
              min="0"
              step="0.01"
              placeholder="e.g. 12.99"
              value={form.price}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="category">Category</label>
            <div className="select-wrapper">
              <select
                id="category"
                name="category"
                className="form-select"
                value={form.category}
                onChange={handleChange}
              >
                <option value="">Select a category…</option>
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <button className="btn btn-primary" type="submit" disabled={loading}>
            {loading ? (
              <>
                <span className="loading-spinner" />
                Adding Book…
              </>
            ) : (
              <>✚ Add Book to Store</>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
