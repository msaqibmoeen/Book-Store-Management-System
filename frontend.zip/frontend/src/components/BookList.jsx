import { useState } from 'react';
import axios from 'axios';

// Fetch real cover from Open Library Covers API (free, no key)
// Uses title+author search to find an ISBN, then loads the cover image
function BookCover({ title, author }) {
  const [src, setSrc] = useState(null);
  const [tried, setTried] = useState(false);
  const [failed, setFailed] = useState(false);

  // Build search URL on first render
  if (!tried) {
    setTried(true);
    const query = encodeURIComponent(`${title} ${author}`);
    fetch(`https://openlibrary.org/search.json?q=${query}&limit=1&fields=cover_i`)
      .then((r) => r.json())
      .then((data) => {
        const coverId = data?.docs?.[0]?.cover_i;
        if (coverId) {
          setSrc(`https://covers.openlibrary.org/b/id/${coverId}-M.jpg`);
        } else {
          setFailed(true);
        }
      })
      .catch(() => setFailed(true));
  }

  const initials = title
    .split(' ')
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join('');

  const bgColors = ['#c8956c','#8b5e3c','#5c3d1e','#a07850','#d4a574','#6b4c30'];
  const colorIndex = title.charCodeAt(0) % bgColors.length;

  if (src && !failed) {
    return (
      <img
        src={src}
        alt={`Cover of ${title}`}
        className="book-cover-img"
        onError={() => setFailed(true)}
      />
    );
  }

  return (
    <div
      className="book-cover-fallback"
      style={{ background: bgColors[colorIndex] }}
    >
      <span>{initials}</span>
    </div>
  );
}

export default function BookList({ books, loading, onBookDeleted }) {
  const handleDelete = async (id) => {
    if (!window.confirm('Remove this book from the store?')) return;
    try {
      await axios.delete(`/books/${id}`);
      onBookDeleted(id);
    } catch {
      alert('Failed to delete book.');
    }
  };

  const totalValue = books.reduce((sum, b) => sum + b.price, 0);
  const categories = [...new Set(books.map((b) => b.category))].length;

  if (loading) {
    return (
      <div>
        <div className="stats-bar">
          {[1, 2, 3].map((i) => (
            <div key={i} className="stat-chip" style={{ opacity: 0.4 }}>
              <div className="stat-value">—</div>
              <div className="stat-label">Loading…</div>
            </div>
          ))}
        </div>
        <div className="card">
          <div className="card-body">
            <div className="empty-state">
              <div className="empty-icon">⏳</div>
              <h3>Loading books…</h3>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Stats */}
      <div className="stats-bar">
        <div className="stat-chip">
          <div className="stat-value">{books.length}</div>
          <div className="stat-label">Total Books</div>
        </div>
        <div className="stat-chip">
          <div className="stat-value">{categories}</div>
          <div className="stat-label">Categories</div>
        </div>
        <div className="stat-chip">
          <div className="stat-value">${totalValue.toFixed(2)}</div>
          <div className="stat-label">Total Value</div>
        </div>
      </div>

      {/* List Card */}
      <div className="card">
        <div className="card-header">
          <div className="card-header-icon">🗃️</div>
          <div>
            <h2>Book Inventory</h2>
            <p>
              {books.length === 0
                ? 'No books yet'
                : `${books.length} book${books.length > 1 ? 's' : ''} in store`}
            </p>
          </div>
        </div>
        <div className="card-body">
          {books.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">📚</div>
              <h3>Your store is empty</h3>
              <p>Add your first book using the form on the left.</p>
            </div>
          ) : (
            <div className="books-list">
              {books.map((book, idx) => (
                <div
                  className="book-card"
                  key={book._id}
                  style={{ animationDelay: `${idx * 0.05}s` }}
                >
                  <div className="book-cover-wrap">
                    <BookCover title={book.title} author={book.author} />
                  </div>
                  <div className="book-info">
                    <div className="book-title">{book.title}</div>
                    <div className="book-author">by {book.author}</div>
                    <div className="book-meta">
                      <span className="book-price">
                        ${Number(book.price).toFixed(2)}
                      </span>
                      <span className="book-category">{book.category}</span>
                    </div>
                  </div>
                  <div className="book-actions">
                    <button
                      className="btn btn-danger"
                      onClick={() => handleDelete(book._id)}
                    >
                      🗑 Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
