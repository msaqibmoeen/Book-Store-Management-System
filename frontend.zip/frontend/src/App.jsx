import { useState, useEffect } from "react";
import axios from "axios";
import BookForm from "./components/BookForm";
import BookList from "./components/BookList";
import "./index.css";

export default function App() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);

  // GET /books on mount
  useEffect(() => {
    (async () => {
      try {
        const res = await axios.get("/books");
        if (res.data.success) setBooks(res.data.data);
      } catch (err) {
        console.error("Failed to fetch books:", err.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const handleBookAdded = (newBook) => {
    setBooks((prev) => [newBook, ...prev]);
  };

  const handleBookDeleted = (id) => {
    setBooks((prev) => prev.filter((b) => b._id !== id));
  };

  return (
    <div className="app">
      {/* Navbar */}
      <nav className="navbar">
        <div className="navbar-brand">
          <div className="navbar-icon">📚</div>
          <div className="navbar-title">
            Book<span>Store</span>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <div className="hero">
        <div className="hero-content">
          <h1>Book Store Management System</h1>
          <p>A reader lives a thousand lives before he dies</p>
        </div>
      </div>

      {/* Main Layout */}
      <main className="main-content">
        <BookForm onBookAdded={handleBookAdded} />
        <BookList
          books={books}
          loading={loading}
          onBookDeleted={handleBookDeleted}
        />
      </main>

      {/* Footer */}
      <footer className="footer">
        Built with <span>MERN Stack</span> — MongoDB · Express · React · Node.js
      </footer>
    </div>
  );
}
